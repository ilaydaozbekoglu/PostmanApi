package com.example.postmanapi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btn_lgn = findViewById(R.id.btn_lgn);

        btn_lgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView txt_username = findViewById(R.id.txt_username);
                TextView txt_password = findViewById(R.id.txt_password);

                String username = txt_username.getText().toString();
                String password = txt_password.getText().toString();

               if (username.isEmpty() && password.isEmpty()){
                   Toast.makeText(Login.this, "Alanlar boş bırakılamaz.", Toast.LENGTH_SHORT).show();
               }
               else{
                   Toast.makeText(Login.this, "Giriş Başarılı", Toast.LENGTH_LONG).show();
                   newActivity(username, password);
               }
            }
        });

    }

    public void newActivity(String username, String password){
        Intent intent = new Intent(Login.this,MainActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("password", password);
        startActivity(intent);
    }
}