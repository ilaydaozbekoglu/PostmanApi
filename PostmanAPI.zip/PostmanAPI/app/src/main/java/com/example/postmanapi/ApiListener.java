package com.example.postmanapi;

import org.json.JSONArray;
import org.json.JSONObject;

public interface ApiListener {
    void onSuccess(JSONArray response);
    void onError(String error);
}
