package com.example.postmanapi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {

    private TextView resultTextView;
    private ListView listView;
    private NetworkManager networkManager;

    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;

    private BottomNavigationView bottomNavigationView;
    private Login login;

    private String username;
    private String sifre;
    private String ticketID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.my_drawer_layout);
        resultTextView = findViewById(R.id.resultTextView);

        resultTextView.setTextSize(20);


        resultTextView.setTextColor(Color.rgb(64,64,64));


        resultTextView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));

        Intent intent = getIntent();
        if (intent != null) {
            username = intent.getStringExtra("username");
            if (username != null) {
                // Kullanıcı adını resultTextView'a göster
                resultTextView.setText("Hoşgeldiniz, " + username);
            }
        }

        networkManager = NetworkManager.getInstance(this);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        login = new Login();




/*
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                // Tüm öğelerin rengini varsayılan rengine getir
                resetItemColors();
                // Tıklanan öğenin rengini değiştir
               item.setIcon(R.drawable.googledocs);
                return true;
            }
        });

    }


    private void resetItemColors() {
        // Tüm öğelerin rengini varsayılan rengine getir
        MenuItem item1 = bottomNavigationView.getMenu().findItem(R.id.person);
        item1.setIcon(R.drawable.folder);

        MenuItem item2 = bottomNavigationView.getMenu().findItem(R.id.home);
        item2.setIcon(R.drawable.googledocs);

        MenuItem item3 = bottomNavigationView.getMenu().findItem(R.id.settings);
        item3.setIcon(R.drawable.setting);
    }
    */
    }



    public void getTicket(MenuItem item) {

        Intent intent = getIntent();
        JSONObject jsonRequest = new JSONObject();
        sifre = intent.getStringExtra("password");


        try {
            jsonRequest.put("KullaniciAdi", username);
            jsonRequest.put("Sifre", sifre);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest apiRequest = new ApiRequest(
                Request.Method.POST,
                ApiEndpoints.TICKET_AL,
                jsonRequest,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        resultTextView.setText(response.toString());
                        System.out.println(response.toString());
                        try {
                            ticketID = response.getString("ID"); // ID'yi çıkarıyoruz
                            System.out.println("Ticket ID: " + ticketID); // Terminalde yazdırıyoruz
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        resultTextView.setText("Volley Error: " + error.toString());
                        System.out.println(error.toString());
                    }
                }
        );

        networkManager.addToRequestQueue(apiRequest);
    }


    public void getKlasorListesi(MenuItem item) {
        //String ticketID = "2b6c9bb0-1483-4a55-bf92-9274f2394ab7";
        String ID = ticketID;
        String url = "https://test.divvydrive.com/Test/Staj/KlasorListesiGetir?ticketID=" + ID;

        JsonArrayRequest apiRequest = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            StringBuilder klasorAdlari = new StringBuilder();
                            StringBuilder klasorSizes = new StringBuilder();

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject klasor = response.getJSONObject(i);
                                String klasorsize = klasor.getString("ID");
                                //klasorSizes.append("ID:").append(klasorsize).append("");
                                String klasorAdi = klasor.getString("Adi");
                                klasorAdlari.append("").append(klasorsize).append(".").append(klasorAdi).append("\n \n");
                            }

                            // Elde edilen klasör adlarını resultTextView içinde göster
                            resultTextView.setText(klasorAdlari.toString());

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        resultTextView.setText("Error: " + error.toString());
                        System.out.println(error.toString());
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                String credentials = "NDSServis:ca5094ef-eae0-4bd5-a94a-14db3b8f3950";
                String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;
            }
        };

        networkManager.addToRequestQueue(apiRequest);
    }

    public void getDosyaListesi(MenuItem item) {
        //String ticketID = "2b6c9bb0-1483-4a55-bf92-9274f2394ab7";
        String ID = ticketID;
        String url = "https://test.divvydrive.com/Test/Staj/DosyaListesiGetir?ticketID=" + ID;

        JsonArrayRequest apiRequest = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            StringBuilder dosyaAdlari = new StringBuilder();

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject dosya = response.getJSONObject(i);
                                String dosyasize = dosya.getString("ID");
                                String dosyaAdi = dosya.getString("Adi");
                                dosyaAdlari.append("").append(dosyasize).append(".").append(dosyaAdi).append("\n ");
                            }

                            // Elde edilen klasör adlarını resultTextView içinde göster
                            resultTextView.setText(dosyaAdlari.toString());

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        resultTextView.setText("Error: " + error.toString());
                        System.out.println(error.toString());
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                String credentials = "NDSServis:ca5094ef-eae0-4bd5-a94a-14db3b8f3950";
                String auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                headers.put("Authorization", auth);
                return headers;
            }
        };

        networkManager.addToRequestQueue(apiRequest);
    }
    public void logineDon(MenuItem item){
        Intent intent = new Intent(MainActivity.this, Login.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

