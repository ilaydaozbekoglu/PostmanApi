package com.example.postmanapi;

public class ApiEndpoints {

        public static final String BASE_URL = "https://test.divvydrive.com/Test/Staj/";
        public static final String TICKET_AL = BASE_URL + "TicketAl";

        // bunları kullanmak yerine Mainactivity'de kodun içine gömüp TicketID alındı.

        public static final String KLASOR_LISTESI_GETIR = "KlasorListesiGetir";

        public static final String DOSYA_LISTESI_GETIR = "DosyaListesiGetir";
}
